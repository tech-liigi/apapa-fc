#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS
#define MAX 100


struct pomiar {
	unsigned int nr_pomiaru;
	unsigned int nr_czujnika;
	char data_i_czas[20];
	double temp;
	struct pomiar* nast;
};

int main() {
	struct pomiar* wsk = NULL, *usuw = NULL, * glowa = NULL;
	unsigned int nr_pomiaru;
	unsigned int nr_czujnika;
	char data_i_czas[20];
	double temp;

	printf("Podaj nazwe pliku: ");
	char nazwa_pliku[MAX];
	scanf("%s", nazwa_pliku);


	FILE* plik = fopen(nazwa_pliku, "r");

	if (plik == NULL) {
		printf("Blad z otwarciem pliku.");
        exit(1);
	}

	fscanf(plik, "%i %i %s %lf", &nr_pomiaru, &nr_czujnika, data_i_czas, &temp);

	while (!feof(plik)) {
		if (glowa == NULL)
			glowa = wsk = (struct pomiar*)malloc(sizeof(struct pomiar));
		else {
			wsk->nast = (struct pomiar*)malloc(sizeof(struct pomiar));
			wsk = wsk->nast;
		}
		wsk->nr_pomiaru = nr_pomiaru;
		wsk->nr_czujnika = nr_czujnika;
		strcpy(wsk->data_i_czas, data_i_czas);
		wsk->temp = temp;
		wsk->nast = NULL;

		fscanf(plik, "%i %i %s %lf", &nr_pomiaru, &nr_czujnika, data_i_czas, &temp);
	}
	fclose(plik);

	struct pomiar* glowa_czujnika[4] = { NULL }; 
	int c[4] = { 0 };
	while (glowa != NULL) {
		struct pomiar* tmp = glowa;
		glowa = glowa->nast;
		tmp->nast = glowa_czujnika[tmp->nr_czujnika - 1];
		c[tmp->nr_czujnika - 1]++;
		glowa_czujnika[tmp->nr_czujnika - 1] = tmp;
	}

	printf("Podaj poczatek nazwy plikow do zapisu:");
	char nazwa_pliku_do_zapisu[MAX];
	scanf("%s", nazwa_pliku_do_zapisu);
    
	for (int i = 0; i < 4; i++) {
		char nazwa_pliku_zapisu[MAX];
		sprintf(nazwa_pliku_zapisu, "%s%d.txt", nazwa_pliku_do_zapisu, i + 1);
		FILE* plik_do_zapisu = fopen(nazwa_pliku_zapisu, "w");
		if (plik_do_zapisu == NULL) {
			printf("Blad z otwarciem pliku.");
			exit(1);
		}

		struct pomiar* tmp = glowa_czujnika[i];
		while (tmp != NULL) {
			fprintf(plik_do_zapisu, "%u %u %s %.2lf\n", tmp->nr_pomiaru, tmp->nr_czujnika, tmp->data_i_czas, tmp->temp);
			tmp = tmp->nast;
		}

		fclose(plik_do_zapisu);
	}
	for (int i = 0; i < 4; i++) {
		printf("W czujniku %d: %d\n", i + 1, c[i]);
	}

	for (int i = 0; i < 4; i++) {
		struct pomiar* tmp = glowa_czujnika[i];
		while (tmp != NULL) {
			struct pomiar* usuw = tmp;
			tmp = tmp->nast;
			free(usuw);
		}
	}


	printf("\nKoniec Programu\n");
	return 0;
}